

/////RUN ORDERS.HTML FIRST/////////////

---------------------------------------------------
---------------CREATE THE FOLLOWING----------------








1- HTML file for donations history page, orders history, payment methods web page, pay by cash and pay by visa. [DONE]
2- Style these HTML files using CSS. [DONE]
3- Upload on Github. []
4- CSS Files created using SCSS






---------------------------------------------------
--------------DONE BY MOHAB ASHRAF-----------------